﻿namespace P04E04.WildFarm.Models.Food;

public class Seeds : Food
{
    public Seeds(int quantity) 
        : base(quantity)
    {
    }

    public override string ToString()
    {
        return $"a";
    }
}