﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P04E04.WildFarm.Models.Interfaces
{
    public interface IAbility
    {
        string ProduceSound();
    }
}
