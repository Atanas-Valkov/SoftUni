﻿namespace P04E04.WildFarm.Models.Interfaces;

public interface IFood
{
     int Quantity { get; }
}