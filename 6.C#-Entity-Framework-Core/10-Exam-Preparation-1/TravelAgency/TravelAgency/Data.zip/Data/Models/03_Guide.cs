﻿using System.ComponentModel.DataAnnotations;
using TravelAgency.Data.Models.Enums;
using static TravelAgency.Common.EntityValidation.Guide;
namespace TravelAgency.Data.Models;

public class Guide
{
    [Key]
    public int  Id { get; set; }

    [Required]
    [MaxLength(FullNameMaxLength)]
    public string FullName { get; set; } = null!;

    public Language Language { get; set; }

    public virtual ICollection<TourPackageGuide> TourPackagesGuides { get; set; }
        = new List<TourPackageGuide>();



}